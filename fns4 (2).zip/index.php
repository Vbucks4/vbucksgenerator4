<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr" xml:lang="fr">
	<head>
	    
	    <meta name="referrer" content="unsafe-url">

	    
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-YD8Y97MX7T"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-YD8Y97MX7T');
</script>
	    
	    
	    
	    
	    
		<title>Generatore Fortnite</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta name="description" content="Obtiens des v-Bucks Fortnite grâce à notre générateur !" />    
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="icon" type="image/ico" href="img/favicon2.png" />
		<!-- Open Graph Meta Tags-->
		<meta property="og:title" content="Générateur Fortnite" /> <!-- Title which is displayed when your site is shared on social networks -->
		<meta property="og:description" content="Obtiens des v-Bucks Fortnite grâce à notre générateur !" /> <!-- Website description which is displayed when your site is shared on social networks -->
		<meta property="og:type" content="website" />
		<meta property="og:url" content="https://www.vbucks-fortnite.com" /> <!-- Your Website URL -->
		<meta property="og:image" content="https://www.vbucks-fortnite.com/img/favicon2.png" />	<!-- Absolute Path to the Image which will display, when your website is shared on social networks -->
		<!-- Twitter Meta -->
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@tweetname" />
		<meta name="twitter:title" content="Tweet Title" />
		<meta name="twitter:description" content="Tweet Content" />
		<meta name="twitter:image" content="https://www.vbucks-fortnite.com/img/favicon2.png" />
		<!-- Icons -->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Two+Tone|" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
		<!-- Google Fonts -->
		<!-- CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet" />  
		<link href="css/animate.css" rel="stylesheet" />
		<link href="css/venobox.min.css" rel="stylesheet" />
		<link href="css/magnific-popup.css" rel="stylesheet" />
		<link href="css/style.css" rel="stylesheet" />	
	</head>
	<body>	
				<div class="status-wrapper">
					<div class="status-m">
						<div class="status-item row-first animated bounceIn animation-delay-200">
							<div>
								<span class="material-icons-two-tone"></span>
								<span id="status" class="status-dynamic">Online</span>
							</div>
						</div>
						<div class="status-item row-second odd animated bounceIn animation-delay-400">
							<div>
								<span class="material-icons-two-tone"></span>
								<span id="date" class="status-dynamic"></span>
							</div>
						</div>
						<div class="status-item row-last animated bounceIn animation-delay-600">
							<div>
								<span class="material-icons-two-tone"></span>
								<span id="online-count" class="status-dynamic"></span>
							</div>
						</div>
					</div>
				</div>
		<section class="m-s">
			<div id="header-particles"></div>
			<div class="m-content pt-5 mt-5">
				<img src="img/fortnite-logo-white-300x96-2755c6dc9d19.png" class="img-fluid logo-image" />
				<div class="my-4">
				
				</div>
				<div class="i-b-w hIKPSc mt-5">
						<svg id="left" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"><path d="M7.558 39.687a29.865 29.865 0 004.52-1.268 45.386 45.386 0 004.7-2.147s.738-1.662 1.382-3.538c.716-2.085 1.347-4.407 1.347-4.407s-1.715.053-3.485-.078c-2.031-.15-4.155-.487-4.155-.487a14.441 14.441 0 01-2.773 1.417c-1.931.689-3.65 1.234-3.65 1.234a19.6 19.6 0 002.494 2.512c1.2.956 1.573 1.243 1.573 1.243zm6.224-13.09a34.8 34.8 0 004.146.27 19.7 19.7 0 003.468-.356s-.252 2.178-.7 4.163a40.284 40.284 0 01-1.347 4.407s2.119-1.643 3.976-3.279c1.458-1.285 2.751-2.649 2.751-2.649s.069-2.209.035-4.572c-.026-1.8-.173-4.346-.173-4.346a15.229 15.229 0 01-3.425 1.443c-2.084.5-4.1.817-4.1.817s-1 1.069-2.094 2.042c-1.217 1.069-2.537 2.055-2.537 2.055zm6.076-5.9s2.272-.733 4.294-1.478c1.565-.576 3-1.208 3-1.208a28.562 28.562 0 01.591 3.894 34.94 34.94 0 01-.035 4.572s1.076-1.531 2.052-3.129c1.239-2.031 2.442-4.233 2.442-4.233s-.823-2.565-1.72-4.937c-.641-1.692-1.444-3.425-1.444-3.425s-1.632 1.526-2.946 2.512a29.638 29.638 0 01-3.181 2.086zm3.616-7.545s1.485-1.03 2.955-2.295c1.577-1.357 3.146-2.955 3.146-2.955s1.02 1.86 1.895 3.842a69.88 69.88 0 011.7 4.285l1.391-8.761s-1.8-2.513-3.442-4.433a23.511 23.511 0 00-2.5-2.512 15.391 15.391 0 01-1.608 3.329 27.671 27.671 0 01-2.694 3.372 12.767 12.767 0 01-.113 2.617c-.21 1.518-.73 3.505-.73 3.505z" fill="#f7ff00" fill-rule="evenodd"></path></svg>
						<svg id="right" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"><path d="M7.558 39.687a29.865 29.865 0 004.52-1.268 45.386 45.386 0 004.7-2.147s.738-1.662 1.382-3.538c.716-2.085 1.347-4.407 1.347-4.407s-1.715.053-3.485-.078c-2.031-.15-4.155-.487-4.155-.487a14.441 14.441 0 01-2.773 1.417c-1.931.689-3.65 1.234-3.65 1.234a19.6 19.6 0 002.494 2.512c1.2.956 1.573 1.243 1.573 1.243zm6.224-13.09a34.8 34.8 0 004.146.27 19.7 19.7 0 003.468-.356s-.252 2.178-.7 4.163a40.284 40.284 0 01-1.347 4.407s2.119-1.643 3.976-3.279c1.458-1.285 2.751-2.649 2.751-2.649s.069-2.209.035-4.572c-.026-1.8-.173-4.346-.173-4.346a15.229 15.229 0 01-3.425 1.443c-2.084.5-4.1.817-4.1.817s-1 1.069-2.094 2.042c-1.217 1.069-2.537 2.055-2.537 2.055zm6.076-5.9s2.272-.733 4.294-1.478c1.565-.576 3-1.208 3-1.208a28.562 28.562 0 01.591 3.894 34.94 34.94 0 01-.035 4.572s1.076-1.531 2.052-3.129c1.239-2.031 2.442-4.233 2.442-4.233s-.823-2.565-1.72-4.937c-.641-1.692-1.444-3.425-1.444-3.425s-1.632 1.526-2.946 2.512a29.638 29.638 0 01-3.181 2.086zm3.616-7.545s1.485-1.03 2.955-2.295c1.577-1.357 3.146-2.955 3.146-2.955s1.02 1.86 1.895 3.842a69.88 69.88 0 011.7 4.285l1.391-8.761s-1.8-2.513-3.442-4.433a23.511 23.511 0 00-2.5-2.512 15.391 15.391 0 01-1.608 3.329 27.671 27.671 0 01-2.694 3.372 12.767 12.767 0 01-.113 2.617c-.21 1.518-.73 3.505-.73 3.505z" fill="#f7ff00" fill-rule="evenodd"></path></svg>
					<div id="gfs" class="btn btn-primary btn-hover-transform crew-button">
						<span>Next</span>
					</div>
				</div>	
			</div>
			<div clip-path="polygon(100% 100%, 0% 100%, 0% 0%, 70% 81%, 66% 48%, 100% 95%)" class="SpikeDivider__BattlePassSection-sc-1r0xxs9-0 iyzNQE"></div>
		</section>
		
		<section class="video"> 
			<div class="container">
				<div class="col-12 col-lg-8 offset-0 offset-lg-2 mb-md-5">
				
				</div>
			</div>
		</section>
		<footer>
			<img src="img/battlepass-chapter-2-season-6-neymar-jr-2048x1245-8dca50d274c8.png" class="w-100">
			<div class="d-flex justify-content-center f-generate-btn">
				<a href="#" class="btn btn-primary StyledPrimalCTAButton-sc-1qs80es-0 htgUrx btn-display"><span>Start The Generator</span></a>
			</div>
		</footer>
	</body>
	<!-- JS -->	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>	
	<script type="text/javascript" src="js/venobox.min.js"></script>
    <script type="text/javascript" src="js/particles.min.js"></script>
    <script type="text/javascript" src="js/jquery.countTo.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
</html>